#include <stdio.h>
#include <math.h>

int main() {

    int participantes, jogadoresPorTime, computadores, quantidadeTimes;
    float potencia, duracao, precoEnergia, precoKit, outrosCustos;
    float consumoEnergia, custoEnergia, custoAlimentacao, custoTotal, custoPorPessoa;

    printf("=== Arena Tech ===\n\n");

    printf("Quantidade de participantes: ");
    scanf("%d", &participantes);

    printf("Jogadores por time: ");
    scanf("%d", &jogadoresPorTime);

    printf("Quantidade de computadores: ");
    scanf("%d", &computadores);

    printf("Potencia de cada computador (W): ");
    scanf("%f", &potencia);

    printf("Duracao do evento em horas: ");
    scanf("%f", &duracao);

    printf("Preco do kWh: R$ ");
    scanf("%f", &precoEnergia);

    printf("Preco do kit de alimentacao: R$ ");
    scanf("%f", &precoKit);

    printf("Outros custos: R$ ");
    scanf("%f", &outrosCustos);


    quantidadeTimes = ceil((float) participantes / jogadoresPorTime);

    consumoEnergia = (computadores * potencia * duracao) / 1000;

    custoEnergia = consumoEnergia * precoEnergia;

    custoAlimentacao = participantes * precoKit;

    custoTotal = custoEnergia + custoAlimentacao + outrosCustos;

    custoPorPessoa = custoTotal / participantes;


    printf("\n=== Relatorio do evento ===\n\n");

    printf("Quantidade de times: %d\n", quantidadeTimes);
    printf("Consumo de energia: %.2f kWh\n", consumoEnergia);
    printf("Custo da energia: R$ %.2f\n", custoEnergia);
    printf("Custo da alimentacao: R$ %.2f\n", custoAlimentacao);
    printf("Outros custos: R$ %.2f\n", outrosCustos);
    printf("Custo total: R$ %.2f\n", custoTotal);
    printf("Custo por participante: R$ %.2f\n", custoPorPessoa);

    return 0;
}