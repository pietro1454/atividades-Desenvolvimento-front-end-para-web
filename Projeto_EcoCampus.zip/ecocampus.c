#include <stdio.h>

int main(void) {
    FILE *entrada, *relatorio;
    char local[100], localMaior[100] = "";
    double consumo, limite;
    double total = 0.0, maior = 0.0, media;
    int quantidade = 0, acimaLimite = 0;

    entrada = fopen("consumo_campus.txt", "r");
    if (entrada == NULL) {
        printf("Erro: nao foi possivel abrir consumo_campus.txt.\n");
        return 1;
    }

    while (fscanf(entrada, "%99s %lf %lf", local, &consumo, &limite) == 3) {
        quantidade++;
        total += consumo;

        if (quantidade == 1 || consumo > maior) {
            maior = consumo;
            snprintf(localMaior, sizeof(localMaior), "%s", local);
        }

        if (consumo > limite) {
            acimaLimite++;
        }
    }
    fclose(entrada);

    media = quantidade > 0 ? total / quantidade : 0.0;

    relatorio = fopen("relatorio_consumo.txt", "w");
    if (relatorio == NULL) {
        printf("Erro: nao foi possivel criar relatorio_consumo.txt.\n");
        return 1;
    }

    printf("===== RELATORIO ECOCAMPUS =====\n");
    fprintf(relatorio, "===== RELATORIO ECOCAMPUS =====\n");

    printf("Locais analisados: %d\n", quantidade);
    fprintf(relatorio, "Locais analisados: %d\n", quantidade);

    printf("Consumo total: %.2f litros\n", total);
    fprintf(relatorio, "Consumo total: %.2f litros\n", total);

    printf("Consumo medio: %.2f litros\n", media);
    fprintf(relatorio, "Consumo medio: %.2f litros\n", media);

    if (quantidade > 0) {
        printf("Maior consumo: %s (%.2f litros)\n", localMaior, maior);
        fprintf(relatorio, "Maior consumo: %s (%.2f litros)\n", localMaior, maior);
    } else {
        printf("Maior consumo: nenhum local cadastrado\n");
        fprintf(relatorio, "Maior consumo: nenhum local cadastrado\n");
    }

    printf("Locais acima do limite: %d\n", acimaLimite);
    fprintf(relatorio, "Locais acima do limite: %d\n", acimaLimite);

    fclose(relatorio);
    printf("Relatorio salvo em relatorio_consumo.txt\n");
    return 0;
}
