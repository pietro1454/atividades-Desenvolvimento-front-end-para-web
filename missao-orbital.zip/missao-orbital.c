#include <stdio.h>

int main(void) {
    int codigoCadete;
    int etapa;
    int pontos;
    int total;
    float media;
    int continuar;

    do {
        printf("===== MISSAO ORBITAL =====\n");


        printf("Codigo do cadete: ");
        scanf("%d", &codigoCadete);
        total = 0;

        
        for (etapa = 1; etapa <= 3; etapa++) {
            
            printf("Pontuacao da etapa %d: ", etapa);
            scanf("%d", &pontos);

            while (pontos < 0 || pontos > 100) {
                printf("Pontuacao invalida! Digite um valor entre 0 e 100: ");
                scanf("%d", &pontos);
            }

            
            total = total + pontos;
        }

        
        media = total / 3.0f;

        printf("---------- RESULTADO ----------\n");
        printf("Cadete: %d\n", codigoCadete);
        printf("Pontuacao total: %d pontos\n", total);
        printf("Media: %.2f\n", media);

        /* Etapa 5: classificar o desempenho (if / else) */
        printf("Classificacao: ");
        if (media >= 85.0f) {
            printf("COMANDANTE DA MISSAO\n");
            printf("Treinamento concluido com excelencia.\n");
        } else if (media >= 70.0f) {
            printf("PILOTO APROVADO\n");
            printf("Cadete autorizado para a missao.\n");
        } else if (media >= 50.0f) {
            printf("CADETE EM RECUPERACAO\n");
            printf("Novo treinamento recomendado.\n");
        } else {
            printf("TREINAMENTO REINICIADO\n");
            printf("Cadete ainda nao autorizado.\n");
        }

        
        if (total == 300) {
            printf("PONTUACAO MAXIMA!\n");
        }

        printf("-------------------------------\n");

        
        printf("Avaliar outro cadete? 1-Sim | 0-Nao: ");
        scanf("%d", &continuar);

    } while (continuar == 1);

    printf("Sistema encerrado.\n");

    return 0;
}